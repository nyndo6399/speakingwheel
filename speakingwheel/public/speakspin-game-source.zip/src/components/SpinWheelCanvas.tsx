import React, { useEffect, useRef, useState } from 'react';
import { Plus, Sparkles, Play, Image as ImageIcon, Camera, Link2 } from 'lucide-react';
import { WheelItem, DualSpinMode } from '../types/game';

interface SpinWheelCanvasProps {
  wheelId: 'wheel-1' | 'wheel-2';
  title: string;
  items: WheelItem[];
  rotationDeg: number;
  isSpinning: boolean;
  winningIndex: number | null;
  pointerKick: boolean;
  sizeVariant?: 'normal' | 'compact';
  onSpinClick: () => void;
  onAddFirstItem: () => void;
  showIndividualSpinButton?: boolean;
  onSlotClick?: (index: number) => void;
  onOpenChangeImages?: () => void;
  onOpenPairMatching?: () => void;
  dualSpinMode?: DualSpinMode;
}

export const SpinWheelCanvas: React.FC<SpinWheelCanvasProps> = ({
  wheelId,
  title,
  items,
  rotationDeg,
  isSpinning,
  winningIndex,
  pointerKick,
  sizeVariant = 'normal',
  onSpinClick,
  onAddFirstItem,
  showIndividualSpinButton = false,
  onSlotClick,
  onOpenChangeImages,
  onOpenPairMatching,
  dualSpinMode,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const imageCacheRef = useRef<Map<string, HTMLImageElement>>(new Map());
  const [imagesVersion, setImagesVersion] = useState(0);

  useEffect(() => {
    let isMounted = true;
    items.forEach((item) => {
      if (item.image && !imageCacheRef.current.has(item.image)) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
          imageCacheRef.current.set(item.image!, img);
          if (isMounted) {
            setImagesVersion((v) => v + 1);
          }
        };
        img.onerror = () => {};
        img.src = item.image;
      }
    });
    return () => {
      isMounted = false;
    };
  }, [items]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = sizeVariant === 'compact' ? 520 : 640;
    const dpr = typeof window !== 'undefined' ? Math.min(window.devicePixelRatio || 1, 2) : 1;
    if (canvas.width !== size * dpr || canvas.height !== size * dpr) {
      canvas.width = size * dpr;
      canvas.height = size * dpr;
    }

    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, size, size);

    const cx = size / 2;
    const cy = size / 2;
    const outerRadius = size / 2 - 14;
    const wheelRadius = outerRadius - 13;
    const N = items.length;

    // Rim & Shadow
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, outerRadius, 0, Math.PI * 2);
    ctx.fillStyle = '#1E293B';
    ctx.shadowColor = 'rgba(15, 23, 42, 0.22)';
    ctx.shadowBlur = 18;
    ctx.shadowOffsetY = 7;
    ctx.fill();
    ctx.restore();

    // Gold inner ring
    ctx.beginPath();
    ctx.arc(cx, cy, outerRadius - 3, 0, Math.PI * 2);
    ctx.strokeStyle = '#F59E0B';
    ctx.lineWidth = 3.5;
    ctx.stroke();

    if (N === 0) {
      ctx.beginPath();
      ctx.arc(cx, cy, wheelRadius, 0, Math.PI * 2);
      ctx.fillStyle = '#F1F5F9';
      ctx.fill();
      ctx.restore();
      return;
    }

    const sectionAngleDeg = 360 / N;
    const degToRad = (deg: number) => (deg * Math.PI) / 180;

    // Slices
    for (let i = 0; i < N; i++) {
      const item = items[i];
      const centerAngleDeg = -90 + i * sectionAngleDeg + rotationDeg;
      const startAngleRad = degToRad(centerAngleDeg - sectionAngleDeg / 2);
      const endAngleRad = degToRad(centerAngleDeg + sectionAngleDeg / 2);
      const isWinner = !isSpinning && winningIndex === i;

      const cachedImg = item.image ? imageCacheRef.current.get(item.image) : undefined;
      const hasImage = Boolean(cachedImg && cachedImg.complete && cachedImg.naturalWidth > 0);

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, wheelRadius, startAngleRad, endAngleRad);
      ctx.closePath();

      // Base background color
      ctx.fillStyle = item.color || '#3B82F6';
      ctx.fill();

      if (isWinner) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
        ctx.fill();
      }

      // Crisp slice divider line
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = N > 14 ? 2 : 3.5;
      ctx.stroke();

      if (isWinner) {
        ctx.strokeStyle = '#FDE047';
        ctx.lineWidth = 6;
        ctx.stroke();
      }
      ctx.restore();

      // Content inside slice: Image / Emoji Badge & Large Bold Text Label
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(degToRad(centerAngleDeg));

      const badgeRadius =
        sizeVariant === 'compact'
          ? N <= 4
            ? 48
            : N <= 6
            ? 40
            : N <= 8
            ? 32
            : 24
          : N <= 4
          ? 60
          : N <= 6
          ? 50
          : N <= 8
          ? 40
          : 30;

      const badgeCenterDist = wheelRadius - badgeRadius - 12;

      // Draw Image Badge if item has an image
      if (hasImage && cachedImg) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(badgeCenterDist, 0, badgeRadius, 0, Math.PI * 2);
        ctx.fillStyle = '#FFFFFF';
        ctx.shadowColor = 'rgba(0, 0, 0, 0.28)';
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.lineWidth = 3.5;
        ctx.strokeStyle = '#FFFFFF';
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(badgeCenterDist, 0, badgeRadius - 1, 0, Math.PI * 2);
        ctx.clip();

        ctx.translate(badgeCenterDist, 0);
        ctx.rotate(Math.PI / 2); // Orient upright relative to the slice

        const drawDiameter = (badgeRadius - 1) * 2;
        const imgAspect = (cachedImg.naturalWidth || 1) / (cachedImg.naturalHeight || 1);
        let drawW = drawDiameter;
        let drawH = drawDiameter;
        if (imgAspect >= 1) {
          drawW = drawDiameter * imgAspect;
          drawH = drawDiameter;
        } else {
          drawW = drawDiameter;
          drawH = drawDiameter / imgAspect;
        }
        ctx.drawImage(cachedImg, -drawW / 2, -drawH / 2, drawW, drawH);
        ctx.restore();
      } else if (item.emoji) {
        // Draw large emoji if no image
        ctx.save();
        ctx.beginPath();
        ctx.arc(badgeCenterDist, 0, badgeRadius, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.96)';
        ctx.shadowColor = 'rgba(0, 0, 0, 0.25)';
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.lineWidth = 3.5;
        ctx.strokeStyle = '#FFFFFF';
        ctx.stroke();

        ctx.translate(badgeCenterDist, 0);
        ctx.rotate(Math.PI / 2);
        const emojiSize = Math.round(badgeRadius * 1.35);
        ctx.font = `${emojiSize}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(item.emoji, 0, 2);
        ctx.restore();
      }

      // Large bold text label designed for classroom projectors
      const labelText = (item.text || `Item ${i + 1}`).trim();
      const capBoundary = sizeVariant === 'compact' ? 38 : 46;

      // Position text along the wedge with optimal space
      const textAnchorX = (hasImage || item.emoji)
        ? wheelRadius - badgeRadius * 2 - 22
        : wheelRadius - 16;

      const maxTextWidth = Math.max(35, textAnchorX - capBoundary);

      const baseFont = sizeVariant === 'compact' ? 17 : 22;
      const initialFontSize =
        N <= 4
          ? baseFont + 6
          : N <= 6
          ? baseFont + 3
          : N <= 8
          ? baseFont + 1
          : N <= 10
          ? baseFont
          : N <= 12
          ? baseFont - 2
          : baseFont - 4;

      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';

      let actualFontSize = initialFontSize;
      ctx.font = `800 ${actualFontSize}px 'Fredoka', 'Plus Jakarta Sans', system-ui, sans-serif`;

      while (actualFontSize > 13 && ctx.measureText(labelText).width > maxTextWidth) {
        actualFontSize -= 1;
        ctx.font = `800 ${actualFontSize}px 'Fredoka', 'Plus Jakarta Sans', system-ui, sans-serif`;
      }

      let displayLabel = labelText;
      if (ctx.measureText(displayLabel).width > maxTextWidth && maxTextWidth > 20) {
        while (
          displayLabel.length > 2 &&
          ctx.measureText(displayLabel + '…').width > maxTextWidth
        ) {
          displayLabel = displayLabel.slice(0, -1);
        }
        displayLabel += '…';
      }

      // When image fills the slice, add a frosted dark contrast badge for 100% legibility
      if (hasImage) {
        const textMetrics = ctx.measureText(displayLabel);
        const padX = 10;
        const padY = 6;
        const badgeX = textAnchorX - textMetrics.width - padX;
        const badgeY = -actualFontSize / 2 - padY / 2;
        const badgeW = textMetrics.width + padX * 2;
        const badgeH = actualFontSize + padY * 2;

        ctx.save();
        ctx.fillStyle = 'rgba(15, 23, 42, 0.72)';
        ctx.shadowColor = 'rgba(0, 0, 0, 0.35)';
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 8);
        ctx.fill();
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.restore();
      }

      // Strong contrast stroke and fill
      ctx.lineJoin = 'round';
      ctx.miterLimit = 2;
      ctx.lineWidth = hasImage ? 3 : sizeVariant === 'compact' ? 4 : 5;
      ctx.strokeStyle = 'rgba(15, 23, 42, 0.9)';
      ctx.strokeText(displayLabel, textAnchorX, 0);

      ctx.fillStyle = '#FFFFFF';
      ctx.fillText(displayLabel, textAnchorX, 0);

      ctx.restore();
    }

    // Boundary Pegs
    for (let i = 0; i < N; i++) {
      const boundaryAngleDeg = -90 + i * sectionAngleDeg - sectionAngleDeg / 2 + rotationDeg;
      const rad = degToRad(boundaryAngleDeg);
      const pegX = cx + Math.cos(rad) * (wheelRadius + 4);
      const pegY = cy + Math.sin(rad) * (wheelRadius + 4);

      ctx.beginPath();
      ctx.arc(pegX, pegY, sizeVariant === 'compact' ? 4 : 5, 0, Math.PI * 2);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();
      ctx.lineWidth = 1.4;
      ctx.strokeStyle = '#0F172A';
      ctx.stroke();
    }

    // Center Cap
    ctx.save();
    const capR = sizeVariant === 'compact' ? 34 : 42;
    ctx.beginPath();
    ctx.arc(cx, cy, capR, 0, Math.PI * 2);
    ctx.fillStyle = '#FFFFFF';
    ctx.shadowColor = 'rgba(15, 23, 42, 0.25)';
    ctx.shadowBlur = 8;
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#1E293B';
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(cx, cy, capR - 8, 0, Math.PI * 2);
    ctx.fillStyle = '#F59E0B';
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = `800 ${sizeVariant === 'compact' ? 12 : 14}px 'Fredoka', sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('SPIN', cx, cy + 1);
    ctx.restore();

    ctx.restore();
  }, [items, rotationDeg, isSpinning, winningIndex, imagesVersion, sizeVariant]);

  const canSpin = items.length >= 2 && !isSpinning;

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isSpinning) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const cx = rect.width / 2;
    const cy = rect.height / 2;
    const dx = mouseX - cx;
    const dy = mouseY - cy;
    const dist = Math.sqrt(dx * dx + dy * dy);

    const baseSize = sizeVariant === 'compact' ? 520 : 640;
    const scale = rect.width / baseSize;
    const capR = (sizeVariant === 'compact' ? 34 : 42) * scale;
    const outerR = (baseSize / 2 - 14) * scale;

    // Center button was clicked
    if (dist <= capR) {
      if (canSpin) onSpinClick();
      return;
    }

    // Outer wheel slice was clicked
    if (dist <= outerR && onSlotClick && items.length > 0) {
      const N = items.length;
      const sectionDeg = 360 / N;
      const angleRad = Math.atan2(dy, dx);
      let angleDeg = (angleRad * 180) / Math.PI;

      let relDeg = (angleDeg - rotationDeg + 90 + sectionDeg / 2) % 360;
      if (relDeg < 0) relDeg += 360;
      const sliceIdx = Math.floor(relDeg / sectionDeg) % N;
      onSlotClick(sliceIdx);
      return;
    }

    if (canSpin) onSpinClick();
  };

  return (
    <div className="relative flex flex-col items-center justify-center select-none max-w-full">
      {/* Title Label for Wheel */}
      <div className="mb-1 flex items-center gap-2">
        {title && (
          <span className="font-display text-xs sm:text-sm font-bold text-slate-800 bg-white/90 px-3 py-1 rounded-xl shadow-xs border border-slate-200">
            {title} ({items.length} ô)
          </span>
        )}
        {onOpenChangeImages && items.length > 0 && (
          <button
            type="button"
            onClick={onOpenChangeImages}
            title="Thay ảnh vào từng ô của vòng xoay này"
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 font-display text-xs font-bold border border-blue-200 shadow-xs transition-colors cursor-pointer"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Thay ảnh các ô</span>
          </button>
        )}
        {onOpenPairMatching && (
          <button
            type="button"
            onClick={onOpenPairMatching}
            title="Cài đặt ghép đôi hợp lý giữa 2 vòng xoay"
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl font-display text-xs font-bold border shadow-xs transition-all cursor-pointer ${
              dualSpinMode === 'matched'
                ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border-emerald-300'
                : 'bg-amber-50 hover:bg-amber-100 text-amber-800 border-amber-300'
            }`}
          >
            <Link2 className="w-3.5 h-3.5" />
            <span>{dualSpinMode === 'matched' ? '🔗 Cặp hợp lý (BẬT)' : '🔗 Ghép cặp'}</span>
          </button>
        )}
      </div>

      {/* Fixed Pointer (▼) */}
      <div className="relative z-20 flex flex-col items-center -mb-5 pointer-events-none">
        <div
          className="transition-transform duration-75 origin-top drop-shadow-md"
          style={{
            transform: pointerKick ? 'rotate(-14deg) scale(1.06)' : 'rotate(0deg) scale(1)',
          }}
        >
          <svg
            width={sizeVariant === 'compact' ? 48 : 56}
            height={sizeVariant === 'compact' ? 44 : 52}
            viewBox="0 0 52 48"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            aria-label="Wheel Pointer"
          >
            <path
              d="M26 45L6 9C4.5 6.3 6.4 3 9.5 3H42.5C45.6 3 47.5 6.3 46 9L26 45Z"
              fill="#EF4444"
              stroke="#FFFFFF"
              strokeWidth="4"
              strokeLinejoin="round"
            />
            <circle cx="26" cy="13" r="5" fill="#FEF08A" />
          </svg>
        </div>
      </div>

      {/* Wheel Canvas Container */}
      <div
        className={`relative flex items-center justify-center ${
          sizeVariant === 'compact'
            ? 'w-[290px] h-[290px] sm:w-[370px] sm:h-[370px] lg:w-[420px] lg:h-[420px]'
            : 'w-[330px] h-[330px] sm:w-[470px] sm:h-[470px] lg:w-[550px] lg:h-[550px]'
        } ${!isSpinning && winningIndex !== null ? 'winner-wheel-glow' : ''}`}
      >
        <canvas
          ref={canvasRef}
          onClick={handleCanvasClick}
          title={
            canSpin
              ? `Nhấp vào ô để thay ảnh, hoặc nhấn nút SPIN ở giữa để quay ${title || 'vòng'}`
              : undefined
          }
          className={`w-full h-full block ${canSpin ? 'cursor-pointer' : 'cursor-default'}`}
        />

        {/* Winner Highlight Badge */}
        {!isSpinning && winningIndex !== null && items[winningIndex] && (
          <div className="absolute top-4 right-2 sm:right-6 pointer-events-none animate-bounce bg-amber-400 text-slate-950 font-display font-bold text-xs sm:text-sm px-2.5 py-1 rounded-xl shadow-md border-2 border-white flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-slate-950" />
            <span>Winner: {items[winningIndex].text}</span>
          </div>
        )}

        {/* Empty State */}
        {items.length === 0 && (
          <div className="absolute inset-6 rounded-full bg-white/95 border-3 border-dashed border-slate-300 flex flex-col items-center justify-center p-4 text-center shadow-inner">
            <p className="font-display text-base sm:text-lg font-bold text-slate-700 mb-1">
              Chưa có ô nào
            </p>
            <button
              type="button"
              onClick={onAddFirstItem}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-display font-bold text-xs shadow-md cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ THÊM Ô</span>
            </button>
          </div>
        )}
      </div>

      {/* Quick Slot Strip beneath wheel: shows all slices with pictures & allows 1-click change image */}
      {items.length > 0 && onSlotClick && (
        <div className="mt-2 w-full max-w-[95vw] sm:max-w-md lg:max-w-lg px-2">
          <div className="flex items-center gap-1.5 overflow-x-auto py-1 px-1 bg-white/75 backdrop-blur-xs rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider pl-1 shrink-0">
              Các ô:
            </span>
            {items.map((it, idx) => (
              <button
                key={it.id}
                type="button"
                onClick={() => onSlotClick(idx)}
                title={`Nhấp để thay ảnh cho Ô ${idx + 1}: ${it.text || 'Chưa đặt tên'}`}
                className="group relative flex items-center gap-1 px-2 py-1 rounded-xl bg-white border border-slate-200 hover:border-blue-400 hover:bg-blue-50 transition-all cursor-pointer shrink-0 shadow-2xs"
              >
                <div
                  className="w-5 h-5 rounded-md overflow-hidden flex items-center justify-center border border-black/10 shrink-0"
                  style={{ backgroundColor: it.color }}
                >
                  {it.image ? (
                    <img
                      src={it.image}
                      alt={it.text}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-[10px]">{it.emoji || '⭐'}</span>
                  )}
                </div>
                <span className="text-[11px] font-bold text-slate-700 max-w-[60px] truncate">
                  {it.text || `Ô ${idx + 1}`}
                </span>
                <Camera className="w-3 h-3 text-slate-400 group-hover:text-blue-600 transition-colors" />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Optional individual spin button in dual mode */}
      {showIndividualSpinButton && (
        <button
          type="button"
          disabled={!canSpin}
          onClick={onSpinClick}
          className={`mt-2 inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl font-display text-xs font-bold transition-all shadow-xs ${
            canSpin
              ? 'bg-slate-800 hover:bg-slate-900 text-white active:scale-95 cursor-pointer'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
          }`}
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>Quay {title || (wheelId === 'wheel-1' ? 'Vòng 1' : 'Vòng 2')}</span>
        </button>
      )}
    </div>
  );
};
